package com.dev.RestWithDocker;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RestWithDockerApplication {

	public static void main(String[] args) {
		SpringApplication.run(RestWithDockerApplication.class, args);
	}

}
