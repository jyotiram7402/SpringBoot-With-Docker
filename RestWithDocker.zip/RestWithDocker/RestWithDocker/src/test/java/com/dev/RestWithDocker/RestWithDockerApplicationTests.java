package com.dev.RestWithDocker;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RestWithDockerApplicationTests {

	@Test
	void contextLoads() {
	}

}
